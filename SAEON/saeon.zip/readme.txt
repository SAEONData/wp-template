=== SAEON ===
Contributors: the SAEON uLwazi team
Tested up to: 5.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Our free theme is designed to support the Elementor plugin layout and standard SAEON stakeholder header. This theme is also fully tested with all SAEON plugins.

== Changelog ==

1.0 : First Release

